<?php

echo password_hash(
    'Aishwarya123',
    PASSWORD_DEFAULT
);